
import UIKit

class MainViewController: UIViewController {
    
    // 用于存储搜索结果的笔记数组
    var searchedNotes = [Note]()
    
    // 静态变量，存储所有笔记
    static var notes = [Note]()
    
    // 搜索控制器，用于实现搜索功能
    var searchController = UISearchController(searchResultsController: nil)
        
    // 表格视图，用于显示笔记列表
    var tableView: UITableView?
    
    // 提示标签，当没有笔记时显示
    let label = UILabel()
    
    // 添加按钮，位于右下角，用于创建新笔记
    let button = AddButton()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 设置视图背景颜色为系统默认背景色
        view.backgroundColor = .systemBackground

        // 配置搜索控制器
        searchController.searchResultsUpdater = self // 设置搜索结果的更新代理
        searchController.obscuresBackgroundDuringPresentation = false // 搜索时不模糊背景
        searchController.searchBar.placeholder = "搜索" // 设置搜索栏的占位符
        definesPresentationContext = true // 确保搜索控制器在当前视图控制器中显示
        
        // 设置导航控制器
        setupNavigationController()
        
        // 设置表格视图
        setupTableView()
        
        // 设置添加按钮
        setupButton()
        
        // 设置提示标签
        setupLabel()
        
        // 从存储中加载笔记
        fetchNotesFromStorage()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        // 如果笔记为空，移除表格视图的单元格
        removeCellIfEmpty()
    }
    
    // 添加按钮的点击事件
    @objc private func didTapButton() {
        
        // 使用 CoreDataManager 创建一个新笔记
        let newNote = CoreDataManager.shared.createNote()
        
        // 将新笔记插入到笔记数组的最前面
        MainViewController.notes.insert(newNote, at: 0)
        
        // 在表格视图中插入新行
        tableView!.beginUpdates()
        tableView!.insertRows(at: [IndexPath(row: 0, section: 0)], with: .automatic)
        tableView!.endUpdates()
        
        // 创建 NoteViewController 并设置相关属性
        let noteVC = NoteViewController()
        noteVC.noteCell = nil
        noteVC.set(noteId: newNote.id) // 设置笔记的 ID，每次点击添加按钮，会自动创建一个ID，用于标识
        noteVC.set(noteCell: (tableView?.cellForRow(at: IndexPath(row: 0, section: 0) ) as! NoteCell)) // 设置关联的单元格
        
        // 导航到 NoteViewController
        navigationController?.pushViewController(noteVC, animated: true)
    }
    
    // 设置添加按钮
    private func setupButton() {
        view.addSubview(button) // 将按钮添加到视图中
        button.setButtonConstraints(view: view) // 设置按钮的约束
        button.addTarget(self, action: #selector(didTapButton), for: .touchUpInside) // 添加点击事件
    }
    
    // 设置提示标签
    private func setupLabel() {
        view.addSubview(label) // 将标签添加到视图中
        label.text = "还没有标签" // 设置标签文本
        label.font = .systemFont(ofSize: 20) // 设置字体大小
        label.textColor = .systemGray // 设置文本颜色
        label.translatesAutoresizingMaskIntoConstraints = false // 禁用自动调整大小
        
        // 设置标签的约束
        NSLayoutConstraint.activate([
            label.heightAnchor.constraint(equalToConstant: 30), // 高度
            label.widthAnchor.constraint(equalToConstant: 120), // 宽度
            label.centerXAnchor.constraint(equalTo: view.centerXAnchor), // 水平居中
            label.centerYAnchor.constraint(equalTo: view.centerYAnchor) // 垂直居中
        ])
    }
    
    // 设置导航控制器
    private func setupNavigationController() {
        title = "笔记" // 设置导航栏标题
        navigationController?.navigationBar.prefersLargeTitles = true // 启用大标题
        navigationController?.navigationBar.backgroundColor = .systemBackground // 设置导航栏背景颜色
        navigationController?.hidesBarsOnSwipe = true // 启用滑动时隐藏导航栏
        navigationItem.hidesSearchBarWhenScrolling = false // 滚动时不隐藏搜索栏
        navigationItem.searchController = searchController // 将搜索控制器添加到导航栏
    }
}

// 实现 UISearchResultsUpdating 协议，用于处理搜索结果的更新
extension MainViewController: UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        // 获取搜索栏的文本
        guard let text = searchController.searchBar.text else {
            return
        }
        
        // 调用搜索方法
        search(text: text)
    }
    
    // 搜索方法
    func search(text: String) {
        // 从存储中搜索笔记
        searchNotesFromStorage(text)
    }
}
