//  NoteViewController.swift
//  NotesApp
//
//  Created by Kostya Lee on 12/01/22.
//

import UIKit

class NoteViewController: UIViewController {
    // 笔记的唯一标识符
    private var noteId: String!
    
    // 用于显示和编辑笔记内容的文本视图
    private var textView: UITextView!
    
    // 用于显示和编辑笔记标题的文本字段
    private var textField: UITextField!
    
    // 当前笔记在笔记数组中的索引
    private var index: Int!
    
    // 关联的笔记单元格（用于更新笔记列表中的显示）
    var noteCell: NoteCell?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 根据 noteId 查找当前笔记在笔记数组中的索引
        index = MainViewController.notes.firstIndex(where: {$0.id == noteId})!
        
        // 设置视图背景颜色为系统默认背景色
        view.backgroundColor = .systemBackground
        
        // 禁用大标题模式
        self.navigationItem.largeTitleDisplayMode = .never
        
        // 设置导航栏的右侧按钮
        setupNavigationBarItem()
        
        // 设置文本视图
        setupTextView()  //大格
        
        // 设置文本字段
        setupTextField()  //小格
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // 获取当前笔记对象
        let note = MainViewController.notes[index]
        
        // 将笔记内容和标题分别设置到文本视图和文本字段中
        textView.text = note.text
        textField.text = note.title//点击单元格后将存储的信息传递给页面中
    }

    override func viewWillDisappear(_ animated: Bool) {//页面消失的时候调用
        super.viewWillDisappear(animated)
        
        // 如果有关联的笔记单元格，则更新其显示内容
        guard let noteCell = noteCell else {
            return
        }
        
        // 准备笔记数据并更新单元格的显示
        noteCell.prepareNote()//准备阶段，清空
        noteCell.configure(note: MainViewController.notes[index])//找到notes数组中对应的数据
        noteCell.configureLabels()
    }
    
    // 设置导航栏的右侧按钮
    private func setupNavigationBarItem() {
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(dismissKeyboard))
    }

    // 设置文本视图
    private func setupTextView() {
        textView = CustomtextView(frame: .zero) // 创建自定义文本视图
        view.addSubview(textView) // 将文本视图添加到视图中
        textView.delegate = self // 设置文本视图的代理
        
        // 设置文本视图的约束
        NSLayoutConstraint.activate([
            textView.centerXAnchor.constraint(equalTo: view.centerXAnchor), // 水平居中
            textView.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: view.frame.size.height * 0.09), // 垂直居中，稍微偏下
            textView.heightAnchor.constraint(equalTo: view.heightAnchor, constant: -115), // 高度为视图高度减去 115
            textView.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -56) // 宽度为视图宽度减去 56
        ])
    }
    
    // 设置文本字段
    private func setupTextField() {
        textField = CustomTextField(frame: .zero) // 创建自定义文本字段
        view.addSubview(textField) // 将文本字段添加到视图中
        textField.delegate = self // 设置文本字段的代理
        
        // 设置文本字段的约束
        NSLayoutConstraint.activate([
            textField.bottomAnchor.constraint(equalTo: textView.topAnchor, constant: -10), // 位于文本视图上方，间距为 10
            textField.centerXAnchor.constraint(equalTo: view.centerXAnchor), // 水平居中
            textField.heightAnchor.constraint(equalToConstant: 30), // 高度为 30
            textField.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -70) // 宽度为视图宽度减去 70
        ])
    }
    
    // 设置当前笔记的 ID
    func set(noteId: String) {
        self.noteId = noteId
    }
    
    // 设置关联的笔记单元格
    func set(noteCell: NoteCell) {
        self.noteCell = noteCell
    }
}

// 实现 UITextViewDelegate 和 UITextFieldDelegate 协议，用于处理文本输入的变化
extension NoteViewController: UITextViewDelegate, UITextFieldDelegate {
    
    // 当文本视图的内容发生变化时调用
    func textViewDidChange(_ textView: UITextView) {
        // 更新当前笔记的内容
        MainViewController.notes[index].text = textView.text
        
        // 保存更改到 CoreData
        CoreDataManager.shared.save()
    }
    
    // 当文本字段的内容发生变化时调用
    func textFieldDidChangeSelection(_ textField: UITextField) {
        // 更新当前笔记的标题
        MainViewController.notes[index].title = textField.text!
        
        // 保存更改到 CoreData
        CoreDataManager.shared.save()
    }
}

// 扩展 NoteViewController，添加键盘收起功能
extension NoteViewController {
    
    // 收起键盘
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}
