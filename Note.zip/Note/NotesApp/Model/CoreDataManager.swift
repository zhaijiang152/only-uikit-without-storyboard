

import Foundation
import CoreData

// CoreData 管理类，负责与 CoreData 数据库的交互
class CoreDataManager {
  
    // CoreData 的持久化容器
    let persistentContainer: NSPersistentContainer //初始化
    
    // 单例实例，确保全局只有一个 CoreDataManager 对象
    static let shared = CoreDataManager(modelName: "MyNotes")
    // 初始化方法，根据模型名称创建持久化容器
   
    init(modelName: String) {
        persistentContainer = NSPersistentContainer(name: modelName)//获取对应名称的持久化容器
    }
 
    // 视图上下文，用于操作 CoreData 数据
    var viewContext: NSManagedObjectContext {
        return persistentContainer.viewContext
    }   //获取对应的（MyNotes文件）视图上下文

    // 加载持久化存储
    func load(completion: (() -> Void)? = nil) {
        persistentContainer.loadPersistentStores {
            (description, error) in
            guard error == nil else {
                // 如果加载失败，抛出致命错误
                fatalError(error!.localizedDescription)
            }
            // 加载成功后执行回调
            completion?()
        }
    }
    
    // 创建一条新笔记
    func createNote() -> Note {
        // 在视图上下文中创建一个新的 Note 对象
        let note = Note(context: viewContext)
        
        // 设置笔记的默认属性
        note.title = ""
        note.text = ""
        note.id = UUID().uuidString // 生成唯一标识符
        note.date = Date() // 设置当前日期
        
        // 保存到数据库
        save()
        
        return note
    } 
    
    // 保存数据到数据库
    func save() {
        // 检查视图上下文是否有未保存的更改
        if viewContext.hasChanges {
            do {
                // 尝试保存更改
                try viewContext.save()
            } catch {
                // 如果保存失败，打印错误信息
                print("Error occured while saving data: \(error.localizedDescription)")
            }
        }
    }
    
    // 从数据库中获取笔记
    func fetchNotes(filter: String? = nil) -> [Note] {
        // 创建 FetchRequest，用于查询 Note 对象,先调用
        let request: NSFetchRequest<Note> = Note.fetchRequest()
        
        // 设置排序描述符，按日期降序排列
        let sortDescriptor = NSSortDescriptor(keyPath: \Note.date, ascending: false)
        request.sortDescriptors = [sortDescriptor]
        
        // 如果有过滤条件，设置查询的谓词
        if let filter = filter {
            // 创建两个谓词，分别用于匹配标题和内容
            let pr1 = NSPredicate(format: "title contains[cd] %@", filter)
            let pr2 = NSPredicate(format: "text contains[cd] %@", filter)
            
            // 将两个谓词组合成一个 OR 条件的复合谓词
            let predicate = NSCompoundPredicate(type: .or, subpredicates: [pr1, pr2])
            request.predicate = predicate
        }
        
        // 执行查询并返回结果，如果查询失败则返回空数组
        return (try? viewContext.fetch(request)) ?? []
    }
    
    // 从数据库中删除一条笔记
    func deleteNote(_ note: Note) {
        // 从视图上下文中删除笔记
        viewContext.delete(note)
        
        // 保存更改
        save()
    }
}
