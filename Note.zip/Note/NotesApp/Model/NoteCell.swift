//  NoteCell.swift
//  NotesApp
//
//  Created by Kostya Lee on 12/01/22.
//

import UIKit

// 自定义表格视图单元格，用于显示笔记的标题、内容和日期
class NoteCell: UITableViewCell {
    
    // 单元格的唯一标识符
    static let id = "NoteCell"
    
    // 当前单元格关联的笔记对象
    private var note: Note?
    
    // 用于显示日期的标签
    var dateLabel: UILabel!

    // 初始化方法，设置单元格的样式和子视图
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .subtitle, reuseIdentifier: reuseIdentifier)
        
        // 设置单元格的背景颜色为系统默认背景色
        self.backgroundColor = .systemBackground
        
        // 设置标题标签的字体为 24 号，半粗体
        textLabel?.font = .systemFont(ofSize: 24, weight: .semibold)
        
        // 设置副标题标签的字体为 20 号，常规体
        detailTextLabel?.font = .systemFont(ofSize: 20, weight: .regular)
        
        // 设置日期标签
        setupDateLabel()
    }
    
    // 必需的初始化方法，用于从 Storyboard 或 XIB 加载单元格
    required init?(coder: NSCoder) {
        fatalError() // 抛出错误，表示不支持从 Storyboard 或 XIB 加载
    }
    
    // 布局子视图的方法
    override func layoutSubviews() {
        super.layoutSubviews()
        // 可以在此方法中调整子视图的布局
    }
    
    // 准备单元格重用时的清理工作
    override func prepareForReuse() {
        super.prepareForReuse()
        // 可以在此方法中重置单元格的状态
    }
    
    // 设置日期标签
    private func setupDateLabel() {
        // 创建日期标签，并设置其大小和对齐方式
        dateLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 74, height: 50))
        dateLabel.textAlignment = .right
        
        // 将日期标签设置为单元格的辅助视图（显示在右侧）
        accessoryView = dateLabel

        // 设置日期标签的文本颜色为灰色
        dateLabel.textColor = .gray
        
        // 设置日期标签的字体为 14 号
        dateLabel.font = .systemFont(ofSize: 14)
    }
        
    // 配置单元格的标签内容
    func configureLabels() {
        // 设置标题标签的文本为笔记的标题
        self.textLabel?.text = note?.title ?? ""
        
        // 设置副标题标签的文本为笔记的内容
        self.detailTextLabel?.text = note?.text ?? ""
        
        // 如果笔记对象为空，则打印错误信息并返回
        guard let note = note else {
            print("Found nil value in variable note")
            return
        }
        // 根据笔记的日期设置日期标签的文本格式
        let formatter = DateFormatter()
        if Date.isToday(day: note.date.get(.day)) {
            // 如果是今天，则显示时间（如 "HH:mm"）
            formatter.dateFormat = "HH:mm"
        } else if Date.isThisYear(year: note.date.get(.year)) {
            // 如果是今年，则显示月份和日期（如 "MMM d"）
            formatter.dateFormat = "MMM d"
        } else {
            // 如果是其他年份，则显示完整日期（如 "MM/dd/yyyy"）
            formatter.dateFormat = "MM/dd/yyyy"
        }
        
        // 将格式化后的日期设置为日期标签的文本
        dateLabel.text = formatter.string(from: note.date)
    }
    
    // 配置单元格的笔记对象
    func configure(note: Note) {
        self.note = note
    }
    
    // 准备单元格重用时清空笔记对象
    func prepareNote() {
        self.note = nil
    }
}
