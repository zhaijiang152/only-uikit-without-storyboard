
import UIKit

// 扩展 MainViewController，实现 UITableViewDelegate 和 UITableViewDataSource 协议
extension MainViewController: UITableViewDelegate, UITableViewDataSource {

    // 判断搜索栏是否为空
    private var searchBarIsEmpty: Bool {
        guard let text = searchController.searchBar.text else {
            return false
        }
        return text.isEmpty
    }

    // 判断是否正在搜索
    private var isSearching: Bool {
        return searchController.isActive && !searchBarIsEmpty
    }

    // 设置表格视图
    internal func setupTableView() {
        // 创建表格视图
        let tableView = UITableView(frame: .zero)
        
        // 注册自定义单元格 NoteCell
        tableView.register(NoteCell.self, forCellReuseIdentifier: NoteCell.id)
        
        // 设置代理和数据源
        tableView.delegate = self
        tableView.dataSource = self
        
        // 将表格视图添加到主视图中
        view.addSubview(tableView)
        
        // 设置表格视图的分隔线颜色
        tableView.separatorColor = .systemGray3
        
        // 将表格视图赋值给类的属性
        self.tableView = tableView
        
        // 禁用自动调整大小，以便使用 Auto Layout 进行布局
        tableView.translatesAutoresizingMaskIntoConstraints = false
        
        // 设置表格视图的约束，使其与主视图等宽等高
        NSLayoutConstraint.activate([
            tableView.widthAnchor.constraint(equalTo: view.widthAnchor),
            tableView.heightAnchor.constraint(equalTo: view.heightAnchor)
        ])
    }
    
    // 返回表格视图的行数
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isSearching {
            // 如果正在搜索，显示搜索结果的数量，并隐藏提示标签
            label.isHidden = true
            return searchedNotes.count
        } else {
            // 如果没有搜索，显示所有笔记的数量，并根据笔记数量显示或隐藏提示标签
            label.isHidden = false
            MainViewController.notes.count == 0 ? label.animateIn() : label.animateOut()
            return MainViewController.notes.count
        }
    }
    
    // 设置表格视图的行高
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat { 85 }
    
    // 配置表格视图的单元格
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // 从重用队列中获取单元格
        guard let cell = tableView.dequeueReusableCell(withIdentifier: NoteCell.id, for: indexPath) as? NoteCell else {
            return UITableViewCell()
        }
        
        // 根据是否正在搜索，配置单元格的笔记数据
        if isSearching {
            cell.configure(note: searchedNotes[indexPath.row])
        } else {
            cell.configure(note: MainViewController.notes[indexPath.row])
        }
        
        // 配置单元格的标签内容
        cell.configureLabels()
        
        // 设置单元格的选中样式为无
        cell.selectionStyle = .none
        
        return cell
    }

    // 处理单元格的点击事件
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // 创建 NoteViewController
        let noteVC = NoteViewController()
        
        // 根据是否正在搜索，设置 NoteViewController 的笔记 ID
        if isSearching {
            noteVC.set(noteId: searchedNotes[indexPath.row].id)
        } else {
            noteVC.set(noteId: MainViewController.notes[indexPath.row].id)
        }
        
        // 获取当前单元格，并设置 NoteViewController 的关联单元格
        guard let cell = tableView.cellForRow(at: indexPath) as? NoteCell else {
            return
        }
        noteVC.set(noteCell: cell)
        
        // 导航到 NoteViewController
        navigationController?.pushViewController(noteVC, animated: true)
    }
    
    // 处理单元格的编辑操作（如删除）
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            removeNote(row: indexPath.row, tableView: tableView)
        }
    }
    
    // 判断单元格是否可编辑
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        if isSearching {
            // 如果正在搜索，单元格不可编辑
            return false
        }
        // 否则，单元格可编辑
        return true
    }
    
    // 删除指定行的笔记
    internal func removeNote(row: Int, tableView: UITableView) {
        // 从存储中删除笔记
        deleteNoteFromStorage(at: row)
        
        // 从笔记数组中移除笔记
        MainViewController.notes.remove(at: row)
        
        // 从表格视图中移除对应的行
        let path = IndexPath(row: row, section: 0)
        tableView.deleteRows(at: [path], with: .top)
    }
    
    // 如果第一个笔记为空，则移除该单元格
    internal func removeCellIfEmpty() {
        guard let firstNoteCell = MainViewController.notes.first else {
            return
        }
        if firstNoteCell.title.trimmingCharacters(in: .whitespaces).isEmpty &&
            firstNoteCell.text.trimmingCharacters(in: .whitespaces).isEmpty {
            removeNote(row: 0, tableView: tableView!)
        }
    }
}

// MARK:- 处理数据（Note）操作的扩展
extension MainViewController {
    
    // 从存储中加载笔记
    func fetchNotesFromStorage() {
        MainViewController.notes = CoreDataManager.shared.fetchNotes()
    }
    
    // 从存储中删除指定索引的笔记
    private func deleteNoteFromStorage(at index: Int) {
        CoreDataManager.shared.deleteNote(MainViewController.notes[index])
    }
    
    // 根据搜索文本从存储中查找笔记
    func searchNotesFromStorage(_ text: String) {
        searchedNotes = CoreDataManager.shared.fetchNotes(filter: text)
        tableView?.reloadData()
    }
}
