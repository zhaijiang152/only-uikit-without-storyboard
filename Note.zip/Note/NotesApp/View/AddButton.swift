//  AddButton.swift
//  NotesApp
//
//  Created by Kostya Lee on 12/01/22.
//

import UIKit

// 自定义按钮类，用于添加笔记的按钮
class AddButton: UIButton {
    
    // 初始化方法，设置按钮的样式和属性
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        // 设置按钮的图标为系统提供的 "rectangle.stack.badge.plus"
        self.setImage(UIImage(systemName: "rectangle.stack.badge.plus"), for: .normal)
        
        // 设置按钮内容的垂直对齐方式为填充
        self.contentVerticalAlignment = .fill
        
        // 设置按钮内容的水平对齐方式为填充
        self.contentHorizontalAlignment = .fill
    }
    
    // 必需的初始化方法，用于从 Storyboard 或 XIB 加载按钮
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    // 设置按钮的约束，使其固定在视图的右下角
    func setButtonConstraints(view: UIView) {
        // 禁用自动调整大小
        self.translatesAutoresizingMaskIntoConstraints = false
        
        // 设置按钮的宽度为 40
        self.widthAnchor.constraint(equalToConstant: 40).isActive = true
        
        // 设置按钮的高度为 40
        self.heightAnchor.constraint(equalToConstant: 40).isActive = true
        
        // 设置按钮的底部与视图的底部对齐，间距为 45
        self.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -45).isActive = true
        
        // 设置按钮的右侧与视图的右侧对齐，间距为 45
        self.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -45).isActive = true
    }
}
