//  CustomTextField.swift
//  NotesApp
//
//  Created by Kostya Lee on 18/01/22.
//

import UIKit

// 自定义文本字段类，用于显示和编辑笔记的标题
class CustomTextField: UITextField {
    
    // 初始化方法，设置文本字段的样式和属性
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        // 禁用自动调整大小，以便使用 Auto Layout 进行布局
        self.translatesAutoresizingMaskIntoConstraints = false
        
        // 设置文本字段的字体为 28 号，粗体
        let font = UIFont.boldSystemFont(ofSize: 28)
        self.font = font
        
        // 禁用自动校正功能
        self.autocorrectionType = .no
        
        // 定义占位符的文本属性
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font, // 字体
            .foregroundColor: UIColor.gray // 文本颜色为灰色
        ]
        
        // 设置占位符文本及其属性
        self.attributedPlaceholder = NSAttributedString(string: "Title", attributes: attributes)
    }
    
    // 必需的初始化方法，用于从 Storyboard 或 XIB 加载文本字段
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
}
