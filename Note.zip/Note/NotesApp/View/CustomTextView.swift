

import UIKit

// 自定义文本视图类，用于显示和编辑笔记的内容
class CustomtextView: UITextView {
    
    // 初始化方法，设置文本视图的样式和属性
    override init(frame: CGRect, textContainer: NSTextContainer?) {
        super.init(frame: frame, textContainer: textContainer)
        
        // 禁用自动调整大小，以便使用 Auto Layout 进行布局
        self.translatesAutoresizingMaskIntoConstraints = false
        
        // 设置文本视图的字体为 20 号，系统默认字体
        let font = UIFont.systemFont(ofSize: 20)
        self.font = font
        
        // 禁用自动校正功能
        self.autocorrectionType = .no
    }
    
    // 必需的初始化方法，用于从 Storyboard 或 XIB 加载文本视图
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
}
