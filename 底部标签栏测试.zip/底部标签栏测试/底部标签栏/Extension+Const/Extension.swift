//
//  Extension.swift
//  TreeFood
//
//  Created by 王韬 on 2021/10/19.
//

import EachNavigationBar
import Foundation
import UIKit
import SwiftyJSON
import HandyJSON

struct TimeAndFood {
    var time: String = "" // 时间，默认为空字符串
    var food: String = "" // 食物，默认为空字符串
}


extension UIImage {
    func image(withIcon iconCode: String?, inFont fontName: String?, size: Int, color: UIColor?) -> UIImage? {
        let imageSize = CGSize(width: CGFloat(size), height: CGFloat(size))
        UIGraphicsBeginImageContextWithOptions(imageSize, _: false, _: UIScreen.main.scale)
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: CGFloat(size), height: CGFloat(size)))
        label.font = UIFont(name: fontName ?? "", size: CGFloat(size))
        label.text = iconCode
        if color != nil {
            label.textColor = color
        }
        if let context = UIGraphicsGetCurrentContext() {
            label.layer.render(in: context)
        }
        let retImage = UIGraphicsGetImageFromCurrentImageContext()
        return retImage
    }
}



extension Double {
    var fit: CGFloat {
        return CGFloat(self / 414.0) * UIScreen.main.bounds.width
    }

    var fitW: CGFloat {
        return CGFloat(self / 414.0) * UIScreen.main.bounds.width
    }

    var fitH: CGFloat {
        return CGFloat(self / 896.0) * UIScreen.main.bounds.width
    }
}

extension Int {
    var fit: Int {
        return Int(CGFloat(self) / 414.0 * UIScreen.main.bounds.width)
    }

    var fitW: Int {
        return Int(CGFloat(self) / 414.0 * UIScreen.main.bounds.width)
    }

    var fitH: Int {
        return Int(CGFloat(self) / 896.0 * UIScreen.main.bounds.width)
    }
}
extension UIColor {
    convenience init(r: CGFloat, g: CGFloat, b: CGFloat) {
        self.init(red: r / 255.0, green: g / 255.0, blue: b / 255.0, alpha: 1.0)
    }
    
    convenience init(r: CGFloat, g: CGFloat, b: CGFloat, alpha: CGFloat) {
        self.init(red: r / 255.0, green: g / 255.0, blue: b / 255.0, alpha: alpha)
    }
}


extension UIColor {
    public convenience init?(hex: String) {
        let r, g, b, a: CGFloat

        if hex.hasPrefix("#") {
            let start = hex.index(hex.startIndex, offsetBy: 1)
            let hexColor = String(hex[start...])

            if hexColor.count == 8 {
                let scanner = Scanner(string: hexColor)
                var hexNumber: UInt64 = 0

                if scanner.scanHexInt64(&hexNumber) {
                    r = CGFloat((hexNumber & 0xFF000000) >> 24) / 255
                    g = CGFloat((hexNumber & 0x00FF0000) >> 16) / 255
                    b = CGFloat((hexNumber & 0x0000FF00) >> 8) / 255
                    a = CGFloat(hexNumber & 0x000000FF) / 255

                    self.init(red: r, green: g, blue: b, alpha: a)
                    return
                }
            }
        }

        return nil
    }
}
extension UIView {
    @IBInspectable
    var cornerRadius: CGFloat {
        get {
            return layer.cornerRadius
        }
        set {
            layer.cornerRadius = newValue
        }
    }
    
}
