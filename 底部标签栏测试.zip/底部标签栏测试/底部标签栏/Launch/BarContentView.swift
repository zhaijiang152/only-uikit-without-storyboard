// BarContentView.swift
// TreeFood
// Created by 王韬 on 2021/10/19.
// 用于实现tabBar点击动画和颜色选项

import ESTabBarController_swift  // 导入ESTabBarController库，用于自定义TabBar
import SnapKit
import UIKit

// 定义一个自定义的TabBarItem内容视图，继承自ESTabBarItemContentView
class BarContentView: ESTabBarItemContentView {
    // 重写初始化方法
    override init(frame: CGRect) {
        super.init(frame: frame)
        // 设置默认文本颜色
        textColor = UIColor(white: 175.0 / 255.0, alpha: 1.0)
        // 设置高亮文本颜色
        highlightTextColor = UIColor(red: 96 / 255.0, green: 114 / 255.0, blue: 255 / 255.0, alpha: 1.0)
        // 设置默认图标颜色
        iconColor = UIColor(white: 175.0 / 255.0, alpha: 1.0)
        // 设置高亮图标颜色
        highlightIconColor = UIColor(red: 0.98, green: 0.59, blue: 0.48, alpha: 1)
    }

    // 定义一个便利初始化方法，传入位置参数
    convenience init(frame: CGRect, postion: String) {
        self.init(frame: frame)
        // 根据位置参数设置内边距
        if postion == "left" {
            insets = UIEdgeInsets(top: 30.fit, left: 0, bottom: 0, right: 20.fit)
        } else if postion == "right" {
            insets = UIEdgeInsets(top: 30.fit, left: 0, bottom: 0, right: -20.fit)
        }
    }

    // 实现必需的初始化方法，如果使用Storyboard或XIB会调用此方法
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // 重写选中动画方法
    override func selectAnimation(animated: Bool, completion: (() -> Void)?) {
        // 执行弹跳动画
        bounceAnimation()
        // 执行完成回调
        completion?()
    }

    // 重写重新选中动画方法
    override func reselectAnimation(animated: Bool, completion: (() -> Void)?) {
        // 执行弹跳动画
        bounceAnimation()
        // 执行完成回调
        completion?()
    }

    // 定义一个弹跳动画方法
    func bounceAnimation() {
        // 创建一个关键帧动画，用于实现缩放效果
        let impliesAnimation = CAKeyframeAnimation(keyPath: "transform.scale")
        // 设置动画的关键帧值
        impliesAnimation.values = [1.0, 1.4, 0.9, 1.15, 0.95, 1.02, 1.0]
        // 设置动画的持续时间
        impliesAnimation.duration = 0.3 * 2
        // 设置动画的计算模式为立方
        impliesAnimation.calculationMode = CAAnimationCalculationMode.cubic
        // 将动画添加到图标图层
        imageView.layer.add(impliesAnimation, forKey: nil)
    }
}

// 扩展ESTabBar，重写hitTest方法
extension ESTabBar {
    override open func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        // 如果视图不可交互、隐藏或透明度小于等于0.01，则返回nil
        if !isUserInteractionEnabled || isHidden || alpha <= 0.01 {
            return nil
        }
        // 调用父类的hitTest方法，获取默认的响应视图
        let resultView = super.hitTest(point, with: event)
        // 如果父类返回了有效的视图，则直接返回该视图
        if resultView != nil {
            return resultView
        } else {
            // 遍历所有子视图，查找是否有子视图可以响应触摸事件
            for subView in subviews.reversed() {
                // 将触摸点转换为子视图的坐标系
                let convertPoint: CGPoint = subView.convert(point, from: self)
                // 调用子视图的hitTest方法，检查子视图是否可以响应触摸事件
                let hitView = subView.hitTest(convertPoint, with: event)
                // 如果子视图可以响应触摸事件，则返回该子视图
                if hitView != nil {
                    return hitView
                }
            }
        }
        // 如果没有找到可以响应触摸事件的视图，则返回nil
        return nil
    }
}
