import UIKit

// 自定义导航控制器类，继承自 UINavigationController
class BaseNavigationController: UINavigationController {

    // 视图加载完成时调用
    override func viewDidLoad() {
        super.viewDidLoad()

        // 获取 UIBarButtonItem 的外观代理
        let appearance = UIBarButtonItem.appearance()

        // 设置返回按钮的标题偏移量为 0，隐藏返回按钮的标题
        appearance.setBackButtonTitlePositionAdjustment(UIOffset(horizontal: 0.0, vertical: 0), for: .default)

        // 设置导航栏为半透明
        navigationBar.isTranslucent = true

        // 设置导航栏的背景颜色为浅灰色（RGB: 250, 250, 250），透明度为 0.8
        navigationBar.barTintColor = UIColor(red: 250 / 255.0, green: 250 / 255.0, blue: 250 / 255.0, alpha: 0.8)

        // 设置导航栏标题的文本属性：
        // 颜色为深灰色（RGB: 38, 38, 38），字体大小为 16
        navigationBar.titleTextAttributes = [
            NSAttributedString.Key.foregroundColor: UIColor(red: 38 / 255.0, green: 38 / 255.0, blue: 38 / 255.0, alpha: 1.0),
            NSAttributedString.Key.font: UIFont.systemFont(ofSize: 16.0)
        ]

        // 设置导航栏的按钮（如返回按钮）颜色为深灰色（RGB: 38, 38, 38）
        navigationBar.tintColor = UIColor(red: 38 / 255.0, green: 38 / 255.0, blue: 38 / 255.0, alpha: 1.0)

        // 开启单独导航栏配置（假设 navigation 是一个自定义的导航配置对象）
        navigation.configuration.isEnabled = true
    }

    // 重写 pushViewController 方法，用于在导航栈中推入新的视图控制器
    override func pushViewController(_ viewController: UIViewController, animated: Bool) {
        // 如果当前导航栈中已有视图控制器（即不是第一个控制器）
        if children.count > 0 {
            // 隐藏底部标签栏（通常是 TabBar）
            viewController.hidesBottomBarWhenPushed = true
        }

        // 调用父类的 pushViewController 方法，推入视图控制器并执行动画
        super.pushViewController(viewController, animated: true)
    }
}
