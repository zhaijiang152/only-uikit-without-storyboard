//
//  lauch.swift
//  底部标签栏
//
//  Created by gaoang on 2025/3/18.
import Foundation
import ESTabBarController_swift
import UIKit

func Launch() -> ESTabBarController{
    
    let tabBarController = ESTabBarController()
    
    let fontVC = ViewController1()
    let clockVC = ViewController2()
    let logVC = ViewController3()
    let calenVC = CalendarViewController()
    
    fontVC.tabBarItem = ESTabBarItem.init(BarContentView(frame: .zero, postion: "left"), title: "", image: UIImage(named: "home"), selectedImage: UIImage(named: "home"))
    clockVC.tabBarItem = ESTabBarItem.init(BarContentView(frame: .zero, postion: "left"), title: "", image: UIImage(named: "recoder"), selectedImage: UIImage(named: "recoder"))
    logVC.tabBarItem = ESTabBarItem.init(BarContentView(frame: .zero, postion: "left"), title: "", image: UIImage(named: "mine"), selectedImage: UIImage(named: "mine"))
    calenVC.tabBarItem = ESTabBarItem.init(BarContentView(frame: .zero, postion: "left"), title: "", image: UIImage(named: "calendar"), selectedImage: UIImage(named: "calendar"))
    
    
    let fontNavi = BaseNavigationController(rootViewController: fontVC)//创建导航栈，并将fontVC作为栈底根视图，以下同理
    let clockNavi = BaseNavigationController(rootViewController: clockVC)
    let logNavi = BaseNavigationController(rootViewController: logVC)
    let calenVavi = BaseNavigationController(rootViewController: calenVC)
    
    tabBarController.viewControllers = [fontNavi,clockNavi,logNavi,calenVavi]
    
    UITabBar.appearance().isTranslucent = false

    UITabBar.appearance().tintColor = .white
    tabBarController.tabBar.barStyle = .default
    tabBarController.tabBar.layer.shadowColor = UIColor.black.cgColor
    tabBarController.tabBar.layer.shadowOffset = CGSize(width: 0, height: -3.fit)
    tabBarController.tabBar.layer.shadowOpacity = 0.2
    tabBarController.tabBar.backgroundColor = .white
    tabBarController.tabBar.shadowImage = UIImage(named: "background")
    tabBarController.tabBar.barTintColor = UIColor.red
    tabBarController.tabBar.backgroundImage = UIImage(named: "background")
    
    
    return tabBarController
}
