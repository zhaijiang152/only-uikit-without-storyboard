//
//  ViewController.swift
//  底部标签栏
//
//  Created by gaoang on 2025/4/6.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

