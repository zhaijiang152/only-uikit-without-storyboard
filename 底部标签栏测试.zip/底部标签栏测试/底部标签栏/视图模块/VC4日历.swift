

import FSCalendar // 导入FSCalendar库，用于实现日历功能
import UIKit // 导入UIKit框架，用于构建用户界面

class CalendarViewController: UIViewController, UIGestureRecognizerDelegate {
    // MARK: - 私有属性

    private var data = [TimeAndFood]() // 用于存储与日期相关的数据（如餐食信息）

    // 懒加载日历视图
    lazy var calendar: FSCalendar = {
        let calendar = FSCalendar(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 300.fit)) // 初始化日历视图
        calendar.dataSource = self // 设置数据源为当前控制器
        calendar.delegate = self // 设置代理为当前控制器
        calendar.locale = NSLocale(localeIdentifier: "zh-CN") as Locale // 设置日历语言为中文
        calendar.appearance.weekdayTextColor = UIColor(r: 120, g: 120, b: 120) // 设置星期文字颜色
        calendar.appearance.headerTitleColor = UIColor(r: 112, g: 112, b: 112) // 设置头部标题颜色
        calendar.placeholderType = .fillHeadTail // 设置占位符类型
        calendar.appearance.caseOptions = .weekdayUsesSingleUpperCase // 设置星期显示格式
        calendar.appearance.todayColor = .clear // 设置今天日期的背景颜色
        calendar.appearance.selectionColor = UIColor(hex: "#F6C98EFF") // 设置选中日期的背景颜色
        calendar.appearance.titlePlaceholderColor = UIColor(hex: "#404040FF") // 设置占位符日期的文字颜色
        calendar.appearance.titleDefaultColor = UIColor(hex: "#F59268FF") // 设置默认日期的文字颜色
        calendar.appearance.titleTodayColor = UIColor(hex: "#F59268FF") // 设置今天日期的文字颜色
        calendar.appearance.titleSelectionColor = UIColor(hex: "#3D1615FF") // 设置选中日期的文字颜色
        calendar.backgroundColor = .clear // 设置日历背景颜色为透明
        return calendar
    }()

    // 懒加载背景图片视图
    lazy var image: UIImageView = {
        let img = UIImageView() // 初始化图片视图
        img.backgroundColor = UIColor(hex: "#FAE7D7FF") // 设置背景颜色
        return img
    }()

    // 懒加载表格头部视图
    lazy var tableViewHeader: UIView = {
        let vi = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50.fit)) // 初始化头部视图
        let button = UIButton() // 初始化按钮
        button.setImage(UIImage(named: "double arrow"), for: .normal) // 设置按钮图片
        vi.addSubview(button) // 将按钮添加到头部视图中
        button.snp.makeConstraints { make in
            make.centerX.equalToSuperview() // 按钮水平居中
            make.top.equalToSuperview().offset(10.fit) // 按钮顶部距离头部视图顶部10.fit
            make.width.height.equalTo(30.fit) // 按钮宽高为30.fit
        }
        button.addTarget(self, action: #selector(loadNext), for: .touchUpInside) // 设置按钮点击事件
        vi.backgroundColor = .white // 设置头部视图背景颜色为白色
        return vi
    }()

    // 懒加载表格视图
    lazy var tableView: UITableView = {
        let tableview = UITableView() // 初始化表格视图
        tableview.delegate = self // 设置代理为当前控制器
        tableview.dataSource = self // 设置数据源为当前控制器
        tableview.showsVerticalScrollIndicator = false // 隐藏垂直滚动条
        tableview.separatorStyle = .none // 隐藏分隔线
        tableview.register(CalendarCollectionViewCell.classForCoder(), forCellReuseIdentifier: "reusedcell") // 注册单元格
        tableview.register(CalendarHeadViewCell.self, forHeaderFooterViewReuseIdentifier: "cell") // 注册头部视图
        tableview.tableHeaderView = tableViewHeader // 设置表格头部视图
        tableview.backgroundColor = .clear // 设置表格背景颜色为透明
        return tableview
    }()

    // 懒加载日期格式化器
    fileprivate lazy var dateFormatter: DateFormatter = {
        let formatter = DateFormatter() // 初始化日期格式化器
        formatter.dateFormat = "yyyy/MM/dd" // 设置日期格式
        return formatter
    }()

    // 懒加载滑动手势
    fileprivate lazy var scopeGesture: UIPanGestureRecognizer = {
        [unowned self] in
        let panGesture = UIPanGestureRecognizer(target: self.calendar, action: #selector(self.calendar.handleScopeGesture(_:))) // 初始化滑动手势
        panGesture.delegate = self // 设置手势代理为当前控制器
        panGesture.minimumNumberOfTouches = 1 // 设置最小触摸点数为1
        panGesture.maximumNumberOfTouches = 2 // 设置最大触摸点数为2
        return panGesture
    }()

    // MARK: -

    override func viewDidLoad() {
        super.viewDidLoad()
        configUI() // 配置UI
        configNavbar() // 配置导航栏
    }

    // MARK: - 私有方法

    // 配置UI
    private func configUI() {
        let isIphoneX = UIScreen.main.bounds.width >= 812 ? true : false
        let kNavBarAndStatusBarHeight : CGFloat = isIphoneX ? 88.0 : 64.0
        view.backgroundColor = .white // 设置视图背景颜色为白色
        view.addSubview(image) // 添加背景图片视图
        image.snp.makeConstraints { make in
            make.right.left.equalTo(view) // 图片左右与视图对齐
            make.top.equalTo(view) // 图片顶部与视图对齐
            make.height.equalTo(500.fit + kNavBarAndStatusBarHeight) // 图片高度为500.fit + 导航栏和状态栏高度
        }
        
        view.addSubview(calendar) // 添加日历视图
        calendar.snp.makeConstraints { make in
            make.right.left.equalTo(view) // 日历左右与视图对齐
            make.top.equalTo(self.navigation.bar.snp.bottom).offset(5.fit) // 日历顶部距离导航栏底部5.fit
            make.height.equalTo(300.fit) // 日历高度为300.fit
        }
        view.addSubview(tableView) // 添加表格视图
        tableView.snp.makeConstraints { make in
            make.right.left.equalTo(view) // 表格左右与视图对齐
            make.top.equalTo(calendar.snp.bottom).offset(5.fit) // 表格顶部距离日历底部5.fit
            make.bottom.equalTo(view) // 表格底部与视图对齐
        }
      
        configCalendar() // 配置日历
    }

    // 配置日历
    private func configCalendar() {
        calendar.select(Date()) // 默认选中今天日期

        view.addGestureRecognizer(scopeGesture) // 添加滑动手势
        tableView.panGestureRecognizer.require(toFail: scopeGesture) // 设置表格滑动手势优先级低于日历滑动手势
        calendar.scope = .month // 设置日历默认范围为月视图

        // For UITest
        calendar.accessibilityIdentifier = "calendar" // 设置日历的辅助功能标识符
    }

    // 配置导航栏
    private func configNavbar() {
        navigation.bar.isShadowHidden = true // 隐藏导航栏阴影
        navigation.bar.alpha = 0 // 设置导航栏透明度为0
        navigation.item.title = "日历" // 设置导航栏标题
    }

    // 手势识别器是否应该开始
    func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        let shouldBegin = tableView.contentOffset.y <= -tableView.contentInset.top // 判断是否需要开始手势
        if shouldBegin {
            let velocity = scopeGesture.velocity(in: view) // 获取滑动手势的速度
            switch calendar.scope {
            case .month:
                return velocity.y < 0 // 如果是月视图，向下滑动时开始手势
            case .week:
                return velocity.y > 0 // 如果是周视图，向上滑动时开始手势
            @unknown default:
                fatalError()
            }
        }
        return shouldBegin
    }

    // 加载下一个视图范围
    @objc func loadNext() {
        if calendar.scope == .month {
            calendar.setScope(.week, animated: true) // 如果是月视图，切换到周视图
        } else {
            calendar.setScope(.month, animated: true) // 如果是周视图，切换到月视图
        }
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension CalendarViewController: UITableViewDelegate, UITableViewDataSource {
    // 返回表格的行数
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3 // 返回3行
    }

    // 返回每一行的单元格
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reusedcell") as! CalendarCollectionViewCell // 获取单元格
        switch indexPath.row {
        case 0:
            cell.title.text = "早餐" // 第一行显示早餐
        case 1:
            cell.title.text = "中餐" // 第二行显示中餐
            cell.label.text = "12:30 AM" // 设置时间
        default:
            cell.title.text = "晚餐" // 第三行显示晚餐
            cell.label.text = "17:30 PM" // 设置时间
        }
        return cell
    }

    // 点击单元格时调用
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true) // 取消选中状态
    }

    // 返回头部视图的高度
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 60.fit // 头部视图高度为60.fit
    }

    // 返回单元格的高度
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 220.fit // 单元格高度为220.fit
    }

    // 返回头部视图
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: "cell") as! CalendarHeadViewCell // 获取头部视图
        headerView.cornerRadius = 40.fit // 设置圆角
        headerView.alpha = 1 // 设置透明度
        return headerView
    }
}

// MARK: - FSCalendarDataSource, FSCalendarDelegate
extension CalendarViewController: FSCalendarDataSource, FSCalendarDelegate {
    // 日历视图大小变化时调用
    func calendar(_ calendar: FSCalendar, boundingRectWillChange bounds: CGRect, animated: Bool) {
        self.calendar.snp.updateConstraints { make in
            make.height.equalTo(bounds.height) // 更新日历视图的高度约束
        }
        view.layoutIfNeeded() // 立即更新布局
    }

    // 选中日期时调用
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        if monthPosition == .next || monthPosition == .previous {
            calendar.setCurrentPage(date, animated: true) // 如果是上个月或下个月，切换到当前日期
        }
    }
}
