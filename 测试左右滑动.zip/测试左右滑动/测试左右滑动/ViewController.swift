import UIKit

class ViewController: UIViewController {
    // 数据源
    let colors: [UIColor] = [.red, .green, .blue, .yellow, .purple]
    
    // 懒加载 UICollectionView
    lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal // 水平滚动
        layout.itemSize = CGSize( width: view.frame.width, height: view.frame.height ) // 单元格大小
        layout.minimumLineSpacing = 0 // 单元格间距为 0
        
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .clear
        collectionView.isPagingEnabled = true // 启用分页
        collectionView.showsHorizontalScrollIndicator = false // 隐藏水平滚动条
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "cell")
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        return collectionView
    }()
    
    // 懒加载 UIPageControl
    lazy var pageControl: UIPageControl = {
        let pageControl = UIPageControl()
        pageControl.numberOfPages = colors.count
        pageControl.currentPage = 0
        pageControl.pageIndicatorTintColor = .lightGray
        pageControl.currentPageIndicatorTintColor = .black
        pageControl.addTarget(self, action: #selector(pageControlChanged), for: .valueChanged)
        pageControl.translatesAutoresizingMaskIntoConstraints = false
        return pageControl
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
    }
    
    // 设置 UI
    func setupUI() {
  
        // 添加 UICollectionView 和 UIPageControl
        view.addSubview(collectionView)
        view.addSubview(pageControl)
        
        // 设置约束
        NSLayoutConstraint.activate([
        
            // collectionView 的顶部与 view 的安全区域顶部对齐
            collectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            
            // collectionView 的左侧与 view 的左侧对齐
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            
            // collectionView 的右侧与 view 的右侧对齐
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            
            // collectionView 的底部与 pageControl 的顶部对齐
            collectionView.bottomAnchor.constraint(equalTo: pageControl.topAnchor),
            
            // pageControl 的底部与 view 的安全区域底部对齐
            pageControl.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            
            // pageControl 的左侧与 view 的左侧对齐
            pageControl.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            
            // pageControl 的右侧与 view 的右侧对齐
            pageControl.trailingAnchor.constraint(equalTo: view.trailingAnchor),

            // pageControl 的高度固定为 50
            pageControl.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    // UIPageControl 值改变时触发
    @objc func pageControlChanged() {
        let offsetX = CGFloat(pageControl.currentPage) * collectionView.frame.width
        collectionView.setContentOffset(CGPoint(x: offsetX, y: 0), animated: true)
    }
}

// MARK: - UICollectionViewDataSource
extension ViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return colors.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        cell.backgroundColor = colors[indexPath.item]
        return cell
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        // 检查 scrollView 的宽度是否为 0 或无效值
        guard scrollView.frame.width > 0 else {
            return
        }
        
        // 计算当前页索引
        let pageIndex = round(scrollView.contentOffset.x / scrollView.frame.width)
        
        // 安全转换为 Int
        if let currentPage = Int(exactly: pageIndex) {
            pageControl.currentPage = currentPage
        } else {
            // 处理转换失败的情况
            print("无法将 pageIndex 转换为 Int，值为无效（NaN 或 infinite）")
        }
    }
}
