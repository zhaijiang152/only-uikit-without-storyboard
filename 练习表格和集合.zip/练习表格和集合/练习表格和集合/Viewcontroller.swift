import UIKit
import Alamofire
import SwiftyJSON
import Hero


class ViewController: UIViewController {
    
    // 定义 cityViewData 数据源
    lazy var cityViewData: [CityView] = {
        return [CityView(), CityView(), CityView()]
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "天气查看"
        addViewandnavigation()
        setupUI()
    }
    
    lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal // 水平滚动
        layout.itemSize = CGSize(width: view.frame.width, height: view.frame.height) // 单元格大小
        layout.minimumLineSpacing = 0 // 单元格间距为 0
        
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .clear
        collectionView.isPagingEnabled = true // 启用分页
        collectionView.showsHorizontalScrollIndicator = false // 隐藏水平滚动条
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "cell")
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        return collectionView
    }()
    
    lazy var pageControl: UIPageControl = {
        let pageControl = UIPageControl()
        pageControl.numberOfPages = cityViewData.count // 根据 cityViewData 的数量设置页数
        pageControl.currentPage = 0
        pageControl.pageIndicatorTintColor = .lightGray
        pageControl.currentPageIndicatorTintColor = .black
        pageControl.addTarget(self, action: #selector(pageControlChanged), for: .valueChanged)
        pageControl.translatesAutoresizingMaskIntoConstraints = false
        return pageControl
    }()
    
    lazy var image1: UIImageView = {
        let imageView = UIImageView(image: UIImage(named: "background"))
        imageView.frame = CGRect(x: -200, y: 0, width: view.frame.width, height: view.frame.height)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    func addViewandnavigation() {
        self.view.addSubview(image1)
        navigationController?.navigationBar.isHidden = false
        navigationItem.hidesSearchBarWhenScrolling = false
        self.navigationController?.navigationBar.tintColor = UIColor.black
    }
    
    func setupUI() {
        // 添加 UICollectionView 和 UIPageControl
        view.addSubview(collectionView)
        view.addSubview(pageControl)
        
        // 设置约束
        NSLayoutConstraint.activate([
  
            collectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 0),
            // collectionView 的左侧与 view 的左侧对齐
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                        
            // collectionView 的右侧与 view 的右侧对齐
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                        
            // collectionView 的底部与 pageControl 的顶部对齐
            collectionView.bottomAnchor.constraint(equalTo: pageControl.topAnchor),
                        
            // pageControl 的底部与 view 的安全区域底部对齐
            pageControl.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
                        
            // pageControl 的左侧与 view 的左侧对齐
            pageControl.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                        
            // pageControl 的右侧与 view 的右侧对齐
            pageControl.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                        
            // pageControl 的高度固定为 50
            pageControl.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    // pageControl 值改变时触发
    @objc func pageControlChanged() {
        let offsetX = CGFloat(pageControl.currentPage) * collectionView.frame.width
        collectionView.setContentOffset(CGPoint(x: offsetX, y: 0), animated: true)
    }
}

// MARK: - UICollectionViewDataSource, UICollectionViewDelegate
extension ViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return cityViewData.count // 返回 cityViewData 的数量
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        
        // 移除旧内容
        cell.contentView.subviews.forEach { $0.removeFromSuperview() }
        
        // 添加对应的 CityView
        let cityView = cityViewData[indexPath.item]
        cell.contentView.addSubview(cityView)
        
        // 设置 CityView 的约束
        cityView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            cityView.topAnchor.constraint(equalTo: cell.contentView.topAnchor),
            cityView.leadingAnchor.constraint(equalTo: cell.contentView.leadingAnchor),
            cityView.trailingAnchor.constraint(equalTo: cell.contentView.trailingAnchor),
            cityView.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor)
        ])
        
        return cell
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        // 检查 scrollView 的宽度是否为 0 或无效值
        guard scrollView.frame.width > 0 else {
            return
        }
        
        // 计算当前页索引
        let pageIndex = round(scrollView.contentOffset.x / scrollView.frame.width)
        
        // 安全转换为 Int
        if let currentPage = Int(exactly: pageIndex) {
            pageControl.currentPage = currentPage
        } else {
            // 处理转换失败的情况
            print("无法将 pageIndex 转换为 Int，值为无效（NaN 或 infinite）")
        }
    }
}
