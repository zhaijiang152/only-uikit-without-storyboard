//
//  hourweather.swift
//  练习表格和集合
//
//  Created by gaoang on 2025/3/23.
//

import UIKit

class hourWeatherCell:  UICollectionViewCell{
   

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupViews() {
        contentView.addSubview(todayCollectionView)
      
        NSLayoutConstraint.activate([
                  // 宽度为屏幕宽度减 40
                  todayCollectionView.widthAnchor.constraint(equalToConstant: ScreenWidth - 40),
                  // 高度为 200
                  todayCollectionView.heightAnchor.constraint(equalToConstant: 200),
                  // 水平居中
                  todayCollectionView.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
                  // 垂直居中
                  todayCollectionView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
              ])
        
    }
    
    
    
    lazy var todayUpText: UILabel = {
        let label = UILabel(frame: CGRect(x: 20, y: 6, width: 100, height: 20))
        label.textColor = .white
        label.font = UIFont.boldSystemFont(ofSize: 13)
        label.text = "24小时预报"
        label.textAlignment = .left
        return label
    }()
    
    let reuseIdenToday = "reusedCellofToday"
    lazy var todayCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = 10
        let collectionView = UICollectionView(frame:.zero, collectionViewLayout: layout)
        collectionView.backgroundColor = UIColor(white: 0.3, alpha: 0.5)
        collectionView.layer.cornerRadius = 30
        collectionView.layer.opacity = 0.8
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: reuseIdenToday)
        collectionView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 30)
        collectionView.addSubview(todayUpText)
        return collectionView
    }()
 
}

extension hourWeatherCell: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 24
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdenToday, for: indexPath)
//        cell.TodayTem.text = "\(todayData[indexPath.row].temperature)°" // 温度
//        cell.TodayWind.text = "\(todayData[indexPath.row].wind_power)" // 风力
//        cell.TodayTime.text = todayData[indexPath.row].time // 时间
//        let code = todayData[indexPath.row].weather_code // 天气代码

        // 根据时间设置天气图标（晚上和白天图标不同）
//        if cell.TodayTime.text! > self.sunSetView.sunSetTime.text! {
//            if (code == "00") || (code == "01") || (code == "03") {
//                cell.TodayWeaImage.image = UIImage(named: "\(code)-1")
//            } else {
//                cell.TodayWeaImage.image = UIImage(named: code)
//            }
//        } else {
//            cell.TodayWeaImage.image = UIImage(named: code)
       
//        }
        return cell
    }
    
    
}

