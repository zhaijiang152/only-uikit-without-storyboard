import UIKit

class WeatherDetailCell: UICollectionViewCell {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupViews() {
        contentView.backgroundColor = .clear
        
        // 日出时间视图
        let sunRiseView = sunRiseD(frame: CGRect(x: 10, y: 10, width: (ScreenWidth - 40) / 2, height: 120))
        
        // 日落时间视图
        let sunSetView = sunSetD(frame: CGRect(x: (ScreenWidth - 40) / 2 + 20, y: 10, width: (ScreenWidth - 40) / 2, height: 120))
        
        // 风力视图
        let windView = windD(frame: CGRect(x: 10, y: 140, width: (ScreenWidth - 40) / 2, height: 120))
        
        // 降水概率视图
        let rainView = rainPossibilityD(frame: CGRect(x: (ScreenWidth - 40) / 2 + 20, y: 140, width: (ScreenWidth - 40) / 2, height: 120))
        
        // 空气质量视图
        let airView = airQualityD(frame: CGRect(x: 10, y: 270, width: (ScreenWidth - 40) / 2, height: 120))
        
        // 大气压视图
        let pressureView = pressureD(frame: CGRect(x: (ScreenWidth - 40) / 2 + 20, y: 270, width: (ScreenWidth - 40) / 2, height: 120))
        
        // 湿度视图
        let moistView = moistD(frame: CGRect(x: 10, y: 400, width: (ScreenWidth - 40) / 2, height: 120))
        
        // 紫外线视图
        let rayView = rayD(frame: CGRect(x: (ScreenWidth - 40) / 2 + 20, y: 400, width: (ScreenWidth - 40) / 2, height: 120))
        
        // 将所有视图添加到 contentView
        contentView.addSubview(sunRiseView)
        contentView.addSubview(sunSetView)
        contentView.addSubview(windView)
        contentView.addSubview(rainView)
        contentView.addSubview(airView)
        contentView.addSubview(pressureView)
        contentView.addSubview(moistView)
        contentView.addSubview(rayView)
    }
}
