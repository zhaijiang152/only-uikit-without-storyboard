//
//  PopAnimationController.swift
//  WeatherApp
//
//  Created by 陈爽 on 2024/8/26.
//


import UIKit

class PopAnimationController:NSObject,UIViewControllerAnimatedTransitioning{
    
    func transitionDuration(using transitionContext:UIViewControllerContextTransitioning?)->TimeInterval{
        return 0.4
    }
    
    func animateTransition(using transitionContext: any UIViewControllerContextTransitioning) {
        guard let fromView = transitionContext.viewController(forKey: .from) as? CityView,
              let toView = transitionContext.viewController(forKey: .to) as? ViewController,
              let selectedIndex = toView.selectedIndex
        else {
            return
        }
        //from进行缩小
        let containerView = transitionContext.containerView
        containerView.insertSubview(toView.view, at: 0)
        toView.view.isHidden = false//确保to是可见的 背景才不会为黑
        toView.collectionView.isHidden = true
        //获取动画的目标框架
        let height = 160+170*(selectedIndex)
        let finalFrame = CGRect(x: 20, y: height, width: Int(ScreenWidth)-40, height: 140)
        let duration = transitionDuration(using: transitionContext)
        
        UIView.animate(withDuration: duration, delay: 0, usingSpringWithDamping: 1.0, initialSpringVelocity:0 ,options:[.curveEaseInOut], animations: {
            fromView.view.frame = finalFrame
            fromView.view.layer.cornerRadius = 25
            fromView.view.layer.masksToBounds = true
            fromView.view.alpha = 0.9
            toView.view.alpha = 1.0
            //显示主页面
        }){_ in
            toView.collectionView.isHidden = false
            toView.collectionView.layoutIfNeeded()
            transitionContext.completeTransition(!transitionContext.transitionWasCancelled)
        }
    }
    
}

