//
//  PushAnimationController.swift
//  WeatherApp
//
//  Created by 陈爽 on 2024/8/26.
//

import UIKit
import Hero

class PushAnimationController:NSObject,UIViewControllerAnimatedTransitioning{
    
    func transitionDuration(using transitionContext:UIViewControllerContextTransitioning?)->TimeInterval{
        return 0.9
    }
    
    func animateTransition(using transitionContext: any UIViewControllerContextTransitioning) {
        guard let fromView = transitionContext.viewController(forKey: .from) as? ViewController,
              let toView = transitionContext.viewController(forKey: .to) as? CityView,
              let selectedCell = fromView.selectedCell
        else {
            return
        }
        
        let containerView = transitionContext.containerView
        let initialFrame = selectedCell.convert(selectedCell.frame, to: fromView.view)//从 selectedCell 的坐标系统转换到 fromVC.view 的坐标系统
        let finalFrame = transitionContext.finalFrame(for: toView)//最后为全部
        
        toView.view.frame = initialFrame//cell的frame
        toView.view.layer.cornerRadius = 25
        toView.view.layer.masksToBounds = true
        toView.view.alpha = 0//to不显示

        containerView.addSubview(toView.view)
        fromView.view.alpha = 1.0//from显示
        let duration = transitionDuration(using: transitionContext)
        UIView.animate(withDuration: duration, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0, options:[.curveEaseInOut],animations: {
            toView.view.frame = finalFrame
            toView.view.alpha = 1.0
            fromView.view.alpha = 0.0
        }){_ in
            fromView.view.alpha = 1.0
            transitionContext.completeTransition(!transitionContext.transitionWasCancelled)
        }
    }
    
}
