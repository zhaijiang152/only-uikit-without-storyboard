//
//  CityCollectionCell.swift
//  WeatherApp
//
//  Created by 陈爽 on 2024/8/24.
//

import UIKit

class CityColletcionCell:UICollectionViewCell{
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        addSubview(cityName)
        addSubview(cityTemRange)
        addSubview(cityTem)
        addSubview(cityWeather)
        setupConstraints()
    }
    
    private func setupConstraints(){
        cityName.translatesAutoresizingMaskIntoConstraints = false
        cityWeather.translatesAutoresizingMaskIntoConstraints = false
        cityTem.translatesAutoresizingMaskIntoConstraints = false
        cityTemRange.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            cityTem.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 260),
            cityTem.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 0),
            cityTem.widthAnchor.constraint(equalToConstant: 170),
            cityTem.heightAnchor.constraint(equalToConstant: 120),//温度
            
            cityTemRange.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 250),
            cityTemRange.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 100),
            cityTemRange.widthAnchor.constraint(equalToConstant: 120),
            cityTemRange.heightAnchor.constraint(equalToConstant: 45),//温度范围
            
            cityName.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 15),
            cityName.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 0),
            cityName.widthAnchor.constraint(equalToConstant: 120),
            cityName.heightAnchor.constraint(equalToConstant: 100),
            
            cityWeather.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 15),
            cityWeather.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 90),
            cityWeather.widthAnchor.constraint(equalToConstant: 50),
            cityWeather.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    lazy var cityName:UILabel = {
        let label = UILabel()
        label.textAlignment = .left
        label.textColor = .white
        label.font = UIFont(name: "Avenir-Book", size: 40)
        return label
    }()
    lazy var cityWeather:UILabel = {
        let label = UILabel()
        label.textAlignment = .left
        label.textColor = .white
        label.font = UIFont(name: "Avenir-Book", size: 25)
        return label
    }()
    lazy var cityTemRange:UILabel = {
        let label = UILabel()
        label.textAlignment = .left
        label.textColor = .white
        label.font = UIFont(name: "Avenir-Book", size: 25)
        return label
    }()
    lazy var cityTem:UILabel = {
        let label = UILabel()
        label.textAlignment = .left
        label.textColor = .white
        label.font = UIFont(name: "Avenir-Book", size: 90)
        return label
    }()
}
