//
//  CityView.swift
//  WeatherApp
//
//  Created by 陈爽 on 2024/8/24.
//

import UIKit
import Alamofire
import SwiftyJSON
import Hero

var futureData:[FutureInfo] = []//未来天气数据
var todayData:[HourInfo] = []//小时天气数据

var gradientLayer = CAGradientLayer()  // 渐变层
let apiKey = "4B097C1688cA4A4Db31F534B0EFd9C3e"

class CityView: UIViewController, UINavigationControllerDelegate{
    
    var now: Data
    var future: Data
    var today:Data
    var backID:String
    
    init(now: Data, future: Data,today:Data,backID:String) {
        self.now = now
        self.future = future
        self.today = today
        self.backID = backID
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    // MARK: - 获取数据
    func getMainWeather(){
        let json = JSON(now)
        let shengname = json["showapi_res_body"]["cityInfo"]["c7"].stringValue//省
        let shiname = json["showapi_res_body"]["cityInfo"]["c3"].stringValue//市
        let minTemp = json["showapi_res_body"]["f1"]["night_air_temperature"].stringValue//最低
        let maxTemp = json["showapi_res_body"]["f1"]["day_air_temperature"].stringValue//最高
        let sun = json["showapi_res_body"]["f1"]["sun_begin_end"].stringValue//日出日落时间
        let currentTime = json["showapi_res_body"]["now"]["temperature_time"].stringValue//得现在的时间
        let uv = json["showapi_res_body"]["f1"]["ziwaixian"].stringValue//紫外线指数
        let pressure = json["showapi_res_body"]["f1"]["air_press"].stringValue//大气压
        let rain = json["showapi_res_body"]["f1"]["jiangshui"].stringValue//降水概率
        let temperature = json["showapi_res_body"]["now"]["temperature"].stringValue//温度
        let weather = json["showapi_res_body"]["now"]["weather"].stringValue//天气
        let humidity = json["showapi_res_body"]["now"]["sd"].stringValue//湿度
        let windlevel = json["showapi_res_body"]["now"]["wind_power"].stringValue//得风力
        let winddeg = json["showapi_res_body"]["now"]["wind_direction"].stringValue//得风向
        let times = sun.components(separatedBy: "|")
        let air = json["showapi_res_body"]["now"]["aqiDetail"]["quality"].stringValue//空气质量
        
        //紫外线 晚上
        if currentTime > times[1]{
            self.rayView.ray.text = "弱"
        }else{
            self.rayView.ray.text = uv
        }
        
        self.temperatureText.text = temperature
        self.weatherText.text = "\(weather)  最低\(minTemp)°  最高\(maxTemp)°"
        self.sunRiseView.sunRiseTime.text = times[0]
        self.sunSetView.sunSetTime.text = times[1]
        self.windView.windLevel.text = windlevel
        self.windView.windWhere.text = winddeg
        self.pressureView.pressure.text = HandleData.shared.ExtractNum(pressure)
        self.moistView.moist.text = humidity
        self.cityText.text = "\(shengname)省 \(shiname)市"
        self.airView.air.text = air
        self.rainView.rainPos.text = rain
        
    }
    
    func getHourWeather(){
        let data = today
        do{
            let weatherResponse = try JSONDecoder().decode(WeatherResponse.self, from: data)
            let hourList = weatherResponse.showapi_res_body.hourList
            for i in hourList{
                var data = HourInfo()//放在里面 否则每次都是覆盖了同一个实例
                data.temperature = i.temperature
                data.time = HandleData.shared.formatTime(i.time,inputformat:"yyyyMMddHHmm",outformat:"HH:mm") ?? "unkonw"//进行格式化mm:hh
                data.weather = i.weather
                data.weather_code = i.weather_code
                data.wind_power = String(i.wind_power.split(separator: " ").first ?? "Unknown")
                todayData.append(data)
            }
            self.todayCollectionView.reloadData()
        }catch{
            print("parse data failed with error: \(error)")
        }
    }
    
    func getFutureWeather(){
        let data = future
        do {
            let weatherResponseFuture = try JSONDecoder().decode(WeatherResponseFuture.self, from: data)
            let dayList = weatherResponseFuture.showapi_res_body.dayList
            for i in dayList{//转化时间
                var data = FutureInfo()
                data.day_air_temperature = i.day_air_temperature
                data.night_air_temperature = i.night_air_temperature
                data.day_weather = i.day_weather
                data.daytime = HandleData.shared.formatTime(i.daytime, inputformat:"yyyyMMdd",outformat:"M-d") ?? "unkonw"
                data.day_weather_code = i.day_weather_code
                futureData.append(data)
            }
            self.futureTableView.reloadData()
        } catch {
            print("parse data failed with error: \(error)")
        }
    }
    // MARK: - 配置
    func setupView(){
        getMainWeather()
        getHourWeather()
        getFutureWeather()
        view.hero.id = "shareId"
        view.hero.isEnabled = true
        view.hero.modifiers = [.scale(0.5)]
        
        HandleData.shared.setWeatherGradientBackground(for: scrollView, weatherCondition: backID)
        scrollView.addSubview(temperatureText)
        scrollView.addSubview(cityText)
        scrollView.addSubview(weatherText)
        scrollView.addSubview(sighText)
        //
        scrollView.addSubview(futureTableView)
        scrollView.addSubview(todayCollectionView)
        //
        scrollView.addSubview(sunRiseView)
        scrollView.addSubview(sunSetView)
        scrollView.addSubview(windView)
        scrollView.addSubview(rainView)
        scrollView.addSubview(airView)
        scrollView.addSubview(pressureView)
        scrollView.addSubview(moistView)
        scrollView.addSubview(rayView)
        //
        self.view.addSubview(scrollView)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.titleTextAttributes = [.backgroundColor:UIColor.clear,.foregroundColor:UIColor.black]
        setupView()
    }

    @objc func clickFuturebtn(){
        let toVC = FutureWeatherView()
        toVC.modalPresentationStyle = .custom//设置为 .custom 是必要的，告知系统使用自定义的过渡动画效果
        present(toVC, animated: true,completion: nil)
    }
    // MARK: - 懒加载属性
    lazy var temperatureText:UILabel = {
        let label = UILabel(frame:CGRect(x:20,y:170, width:250, height:200))
        label.textAlignment = .left
        label.textColor = .white
        label.backgroundColor = .clear
        label.font = UIFont(name: "Avenir-Book", size: 165)
        return label
    }()
    
    lazy var sighText:UILabel = {
        let label = UILabel(frame:CGRect(x:200,y:195, width:60, height:60))
        label.text = "°C"
        label.textAlignment = .left
        label.textColor = .white
        label.backgroundColor = .clear
        label.font = UIFont(name: "Avenir-Book", size: 50)
        return label
    }()
    
    lazy var cityText:UILabel = {
        let label = UILabel(frame:CGRect(x:32,y:155, width:250, height:30))
        label.textAlignment = .left
        label.textColor = .white
        label.backgroundColor = .clear
        label.font = UIFont(name: "Avenir-Book", size: 22)
        return label
    }()
    
    lazy var weatherText: UILabel = {
        let label = UILabel(frame:CGRect(x:25,y:350, width:300, height:30))
        label.textAlignment = .left
        label.textColor = .white
        label.backgroundColor = .clear
        label.font = UIFont(name: "Avenir-Book", size: 20)
        return label
    }()
    
    lazy var scrollView : UIScrollView = {
        let scrollView = UIScrollView(frame:CGRect(x: 0, y:-80, width: ScreenWidth, height:  ScreenHeight + 120))
        scrollView.contentSize = CGSize(width: ScreenWidth, height: CityView.endHeight + 40)
        scrollView.isScrollEnabled = true
        scrollView.backgroundColor = .black
        return scrollView
    }()
    
    lazy var lookMoreFuturebtn : UIButton = {
        let button = UIButton(frame:CGRect(x:40,y:187,width:ScreenWidth-120,height:45))
        button.setTitle("查看近十五日天气", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = UIColor(white: 0.8, alpha: 0.3)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = 15
        button.addTarget(self, action:#selector(clickFuturebtn), for: .touchUpInside)
        return button
    }()
    
    let reuseIdenFuture = "reusedCellofFuture"
    lazy var futureTableView:UITableView = {
        let tableView = UITableView(frame:CGRect(x:20,y:ScreenHeight-260-20,width:ScreenWidth-40,height:240))
        tableView.dataSource = self
        tableView.delegate = self
        tableView.backgroundColor = UIColor(white: 0.3, alpha: 0.5)
        tableView.register(FutureWeatherTableCell.classForCoder(), forCellReuseIdentifier: reuseIdenFuture)
        tableView.layer.cornerRadius = 30
        tableView.layer.opacity = 0.8
        tableView.addSubview(lookMoreFuturebtn)
        return tableView
    }()
    
    lazy var todayUpText:UILabel = {
        let label = UILabel(frame: CGRect(x: 20, y: 6, width: 100, height: 20))
        label.textColor = .lightGray
        label.font = UIFont.boldSystemFont(ofSize: 13)
        label.text = "24小时预报"
        label.textAlignment = .left
        return label
    }()
    
    let reuseIdenToday = "reusedCellofToday"
    lazy var todayCollectionView :UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = 10
        let collectionView = UICollectionView(frame: CGRect(x:20,y:ScreenHeight+20,width:ScreenWidth-40,height:200), collectionViewLayout:layout)

        collectionView.backgroundColor = UIColor(white: 0.3, alpha: 0.5)
        collectionView.layer.cornerRadius = 30
        collectionView.layer.opacity = 0.8
        
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.register(TodayCollectionViewCell.self, forCellWithReuseIdentifier: reuseIdenToday)
        collectionView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 30)
        collectionView.addSubview(todayUpText)
        return collectionView
    }()
    
    static let startHeight = ScreenHeight+220+20
    let sunRiseView = sunRiseD(frame: CGRect(x: 20, y: startHeight, width: 193, height: 120))
    let sunSetView = sunSetD(frame: CGRect(x: 220, y: startHeight, width: 193, height: 120))
    let windView = windD(frame:CGRect(x: 20, y: startHeight+126, width: 193, height: 120))
    let rainView = rainPossibilityD(frame: CGRect(x: 220, y: startHeight+126, width: 193, height: 120))
    let airView = airQualityD(frame: CGRect(x: 20, y: startHeight+126*2, width: 193, height: 120))
    let pressureView = pressureD(frame: CGRect(x: 220, y: startHeight+126*2, width: 193, height: 120))
    let moistView = moistD(frame: CGRect(x: 20, y: startHeight+126*3, width: 193, height: 120))
    let rayView = rayD(frame: CGRect(x: 220, y: startHeight+126*3, width: 193, height: 120))
    static let endHeight = startHeight+126*4

}

// MARK: - tableView 代理方法
extension CityView : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdenFuture, for: indexPath) as! FutureWeatherTableCell
        cell.backgroundColor = .clear
        
        cell.weaImage.image = nil
        cell.time.text = nil
        cell.weather.text = nil
        cell.temRange.text = nil
        
        if futureData.count>0
        {
            cell.time.text = futureData[indexPath.row].daytime
            cell.weather.text = futureData[indexPath.row].day_weather
            cell.weaImage = UIImageView(image: UIImage(named: futureData[indexPath.row].day_weather_code))
            cell.temRange.text = "\(futureData[indexPath.row].night_air_temperature)° ~ \(futureData[indexPath.row].day_air_temperature)°"
        }
        cell.backgroundColor = .clear
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
}
// MARK: - CollectionView代理方法
extension CityView : UICollectionViewDelegate ,UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return todayData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdenToday, for: indexPath) as! TodayCollectionViewCell
        cell.TodayTem.text = "\(todayData[indexPath.row].temperature)°"
        cell.TodayWind.text = "\(todayData[indexPath.row].wind_power)"
        //时间 当前
        cell.TodayTime.text = todayData[indexPath.row].time
        let code = todayData[indexPath.row].weather_code
        //图案 早晚图案不一样 只有0 1 3有早晚之分
        if cell.TodayTime.text! > self.sunSetView.sunSetTime.text!{
            if (code == "00" ) || (code == "01")||(code == "03")
            {
                cell.TodayWeaImage.image = UIImage(named: "\(code)-1")
            }else{
                cell.TodayWeaImage.image = UIImage(named: code)
            }
        }else{
            cell.TodayWeaImage.image = UIImage(named: code)
        }
        return cell
    }
}

extension CityView : UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 50, height: 200)
    }
}

/*extension CityView: UIViewControllerTransitioningDelegate {

    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        guard let _ = presenting as? ViewController, let _ = presented as? FutureWeatherView else {
            return nil
        }
        return PushACfuture()
    }
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        guard let _ = dismissed as? FutureWeatherView else {
            return nil
        }
        return PopACfuture()
    }
}*/
