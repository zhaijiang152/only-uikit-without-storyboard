//
//  FutureWeatherTableCell.swift
//  WeatherApp
//
//  Created by 陈爽 on 2024/8/15.
//

import UIKit

class FutureWeatherTableCell : UITableViewCell {
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    lazy var time : UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.textAlignment = .left
        label.backgroundColor = .clear
        label.font = UIFont(name: "Avenir-Book", size: 20)
        return label
    }()
    
    lazy var weather : UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.textAlignment = .left
        label.backgroundColor = .clear
        label.font = UIFont(name: "Avenir-Book", size: 20)
        return label
    }()
    
    lazy var weaImage:UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var temRange:UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.textAlignment = .left
        label.backgroundColor = .clear
        label.font = UIFont.boldSystemFont(ofSize: 20)
        return label
    }()
    
    
    private func setupConstraints(){
        NSLayoutConstraint.activate([
            time.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            time.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 4),
            time.widthAnchor.constraint(equalToConstant: 60),
            time.heightAnchor.constraint(equalToConstant: 60),
            
            weather.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 80),
            weather.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 4),
            weather.widthAnchor.constraint(equalToConstant: 150),
            weather.heightAnchor.constraint(equalToConstant: 60),
            
            temRange.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: ScreenWidth * 0.65),
            temRange.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 4),
            temRange.widthAnchor.constraint(equalToConstant: ScreenWidth*0.3),
            temRange.heightAnchor.constraint(equalToConstant: 60),
            
            weaImage.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: ScreenWidth * 0.40),
            weaImage.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10),
            weaImage.widthAnchor.constraint(equalToConstant: 45),
            weaImage.heightAnchor.constraint(equalToConstant: 45),
        ])
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        time.translatesAutoresizingMaskIntoConstraints = false
        weather.translatesAutoresizingMaskIntoConstraints = false
        temRange.translatesAutoresizingMaskIntoConstraints = false
        weaImage.translatesAutoresizingMaskIntoConstraints = false
        addSubview(time)
        addSubview(weather)
        addSubview(temRange)
        addSubview(weaImage)
        setupConstraints()
    }
}
