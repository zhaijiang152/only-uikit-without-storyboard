//
//  HandleData.swift
//  WeatherApp
//
//  Created by 陈爽 on 2024/8/20.
//
import UIKit

class HandleData{
    static let shared = HandleData()
    
    private init(){}
    
    func getTime(_ value:Int)->String{
        let timestamp = TimeInterval(value)//时间戳
        let date = Date(timeIntervalSince1970: timestamp)//转为Data对象
        let dataFormatter = DateFormatter()//创建一个DataFormatter来格式化对象
        dataFormatter.timeZone = TimeZone(abbreviation: "UTC+8")//设置为UTC+8时区
        dataFormatter.dateFormat = "HH:mm"//设置时间格式
        let result = dataFormatter.string(from: date)//转化为字符串
        return result
    }
    
    func ExtractNum(_ value:String)->String{
        var number:Substring = ""
        do {
            let regex = try NSRegularExpression(pattern: "\\d+", options: [])//创建正则表达式
            let matches = regex.matches(in: value, options: [], range: NSRange(location: 0, length: value.utf16.count))//进行匹配
            if let match = matches.first {//如果找到第一个匹配的话 如果要匹配多个 则去掉first
                if let range = Range(match.range, in: value) {//得到匹配的范围
                    number = value[range]//提取子字符串
                }
            }
        }catch{
            print("An error occurred while creating the regular expression: \(error)")
        }
        return String(number)
    }
    
    func formatTime(_ time:String,inputformat:String,outformat:String)->String?{
        let inputFormatter = DateFormatter()
        inputFormatter.dateFormat = inputformat
        
        let outputFormatter = DateFormatter()
        outputFormatter.dateFormat = outformat
        
        guard let date = inputFormatter.date(from: time) else { return nil }
        return outputFormatter.string(from: date)
    }
    
    func setWeatherGradientBackground(for view: UIView, weatherCondition: String) {
        let gradientLayer = CAGradientLayer()
        
        // 颜色定义
        if weatherCondition == "sunRiseSet"{
            let topColor = UIColor(red: 25.0/255.0, green: 25.0/255.0, blue: 112.0/255.0, alpha: 1.0).cgColor
            let middleColor = UIColor(red: 255.0/255.0, green: 140.0/255.0, blue: 0.0/255.0, alpha: 1.0).cgColor
            let bottomColor = UIColor(red: 255.0/255.0, green: 215.0/255.0, blue: 100.0/255.0, alpha: 1.0).cgColor
            gradientLayer.colors = [topColor, middleColor, bottomColor]
            gradientLayer.locations = [0.0, 0.5, 1.0]
        }else{
            let sunnyDayTopColor = UIColor(red: 135.0/255.0, green: 206.0/255.0, blue: 250.0/255.0, alpha: 1.0).cgColor
            let rainyDayTopColor = UIColor(red: 80.0/255.0, green: 85.0/255.0, blue: 95.0/255.0, alpha: 1.0).cgColor
            let sunnyDayBottomColor = UIColor(red: 255.0/255.0, green: 215.0/255.0, blue: 100.0/255.0, alpha: 1.0).cgColor
            let rainyDayBottomColor = UIColor(red: 40.0/255.0, green: 45.0/255.0, blue: 55.0/255.0, alpha: 1.0).cgColor
            let badAirtopColor = UIColor(red: 151.0/255.0, green: 151.0/255.0, blue: 151.0/255.0, alpha: 1.0).cgColor
            let badAirBottomColor = UIColor(red: 72.0/255.0, green: 72.0/255.0, blue: 72.0/255.0, alpha: 1.0).cgColor
            
            // 根据天气条件选择颜色
            var topColor: CGColor
            var bottomColor: CGColor
            
            switch weatherCondition {
            case "sunnyDay":
                topColor = sunnyDayTopColor
                bottomColor = sunnyDayBottomColor
            case "rainyDay":
                topColor = rainyDayTopColor
                bottomColor = rainyDayBottomColor
            case "sunnyEvening":
                topColor = UIColor(red: 100.0/255.0, green: 149.0/255.0, blue: 237.0/255.0, alpha: 1.0).cgColor
                bottomColor = UIColor(red: 70.0/255.0, green: 130.0/255.0, blue: 180.0/255.0, alpha: 1.0).cgColor
            case "rainyEvening":
                topColor = UIColor(red: 70.0/255.0, green: 130.0/255.0, blue: 180.0/255.0, alpha: 1.0).cgColor
                bottomColor = UIColor(red: 50.0/255.0, green: 100.0/255.0, blue: 150.0/255.0, alpha: 1.0).cgColor
            case "badAirDay":
                topColor = badAirtopColor
                bottomColor = badAirBottomColor
            default:
                topColor = sunnyDayTopColor
                bottomColor = sunnyDayBottomColor
            }
            
            // 配置渐变层
            gradientLayer.colors = [topColor, bottomColor]
            gradientLayer.locations = [0.0, 1.0]
        }
        
        //单元格保留其圆角 进行类型转化
        if let collectionViewCell = view as? UICollectionViewCell {
            gradientLayer.cornerRadius = 25
            gradientLayer.frame = collectionViewCell.bounds
            collectionViewCell.layer.masksToBounds = true // 确保圆角效果显示
        }else if let scrollView = view as? UIScrollView{
            gradientLayer.frame = CGRect(x: 0, y:-80, width: ScreenWidth, height:  scrollView.contentSize.height + 80)
        }
    // 将渐变层添加到视图
        view.layer.insertSublayer(gradientLayer, at: 0)
    }
    func formatCityName(_ raw: String) -> String {
        let suffixes = ["市", "省", "自治区", "特别行政区"]
        var formatted = raw
        for suffix in suffixes {
            if formatted.hasSuffix(suffix) {
                formatted = String(formatted.dropLast(suffix.count))
                break // 只需处理一次
            }
        }
        return formatted
    }
}
