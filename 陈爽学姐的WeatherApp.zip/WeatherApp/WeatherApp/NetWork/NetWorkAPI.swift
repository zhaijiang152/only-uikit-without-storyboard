//
//  NetWorkAPI.swift
//  WeatherApp
//
//  Created by 陈爽 on 2024/8/20.
//

import Foundation
import Alamofire
import SwiftyJSON

//进行数据的解析
class NetWorkAPI {
    
    static func GetWeatherInformation(url:String,parameters:Parameters?,completion:@escaping(Result<Data,Error>)->Void) -> DataRequest{
        
        //进行网络请求
        NetWorkManager.shared.requestGet(url: url, parameters: parameters){AFResult in
            switch AFResult{
            case let .success(AFdata):
                let ParseResult:Result<Data,Error> = self.parseData(AFdata)
                completion(ParseResult)
                break
            case let .failure(error):
                completion(.failure(error))
                break
            }
        }
    }
    
    private static func parseData<T:Decodable>(_ data:Data) -> Result<T,Error> {
        guard let reponse = try? JSONDecoder().decode(T.self, from: data) else{
            let error = NSError(domain: "NetworkAPIError", code: 0, userInfo: [NSLocalizedDescriptionKey:"can not parse data"])
            return .failure(error)
        }
        return .success(reponse)
    }
}
