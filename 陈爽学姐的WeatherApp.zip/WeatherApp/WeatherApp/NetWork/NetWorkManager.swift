//
//  NetWorkManager.swift
//  WeatherApp
//
//  Created by 陈爽 on 2024/8/20.
//

import Foundation
import Alamofire
import SwiftyJSON

typealias NetWorkRequestResult = Result<Data,Error>
typealias NetWorkCompletionHandler = (NetWorkRequestResult) -> Void

//进行网络请求，网络问题 封装
class NetWorkManager {
    static let shared = NetWorkManager()//设置为单例模式
    
    private init(){}//外部无法再创建新的变量
    
    @discardableResult
    func requestGet(url:String,parameters:Parameters?,completion:@escaping NetWorkCompletionHandler)->DataRequest
    {
        AF.request(url,
                   parameters: parameters,
                   requestModifier: {$0.timeoutInterval = 15})
        .responseData(completionHandler: { response in
            switch response.result{
            case let .success(data):
                completion(.success(data))
                break
            case let .failure(error):completion(self.handleError(error))
                break
            }
        })
    }
    
    @discardableResult
    func requestPost(url:String,parameters:Parameters?,completion:@escaping NetWorkCompletionHandler)->DataRequest
    {
        AF.request(url,
                   method: .post,
                   parameters: parameters,
                   encoding: JSONEncoding.default,
                   requestModifier: {$0.timeoutInterval = 10})
        .responseData(completionHandler: { response in
            switch response.result{
            case let .success(data):completion(.success(data))
                break
            case let .failure(error):completion(self.handleError(error))
                break
            }
        })
    }
    
    private func handleError(_ error:AFError) -> NetWorkRequestResult{
        //如果属于网络问题
        if let underlyingError = error.underlyingError{
            let nserror = underlyingError as NSError//转化为NSError 修改用户友好信息即可
            let code = nserror.code
            if code == NSURLErrorNotConnectedToInternet ||
                code == NSURLErrorTimedOut ||
                code == NSURLErrorInternationalRoamingOff ||
                code == NSURLErrorDataNotAllowed ||
                code == NSURLErrorCannotFindHost ||
                code == NSURLErrorCannotConnectToHost ||
                code == NSURLErrorNetworkConnectionLost
            {
                var userInfo = nserror.userInfo
                userInfo[NSLocalizedDescriptionKey] = "网络连接有问题😯"
                let currentError = NSError(domain: nserror.domain, code: code,userInfo: userInfo)
                return .failure(currentError)
            }
        }
        return .failure(error)
    }
    
    func fetchMultipleData(urls: [String], parameters: [Parameters?], completion: @escaping (Result<[Data], Error>) -> Void) 
    {
        let dispatchGroup = DispatchGroup()
        var results = [Data?](repeating: nil, count: urls.count)
        var requestError: Error?
        
        for (index, url) in urls.enumerated() {
            dispatchGroup.enter()
            requestGet(url: url, parameters: parameters[index]) { result in
                switch result {
                case .success(let data):
                    results[index] = data
                case .failure(let error):
                    requestError = error
                }
                dispatchGroup.leave()
            }
        }
        
        dispatchGroup.notify(queue: .main) {
            if let error = requestError {
                completion(.failure(error))
            } else {
                completion(.success(results.compactMap { $0 }))
            }
        }
    }
}
