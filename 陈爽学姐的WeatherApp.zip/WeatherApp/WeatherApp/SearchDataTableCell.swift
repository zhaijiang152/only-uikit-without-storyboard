//
//  SearchDataTAbleCell.swift
//  WeatherApp
//
//  Created by 陈爽 on 2024/8/23.
//


import UIKit

class SearchDataTableCell:UITableViewCell{
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    lazy var mainText:UILabel = {
        let label = UILabel(frame: CGRect(x: 30, y: 5, width: 200, height: 30))
        label.font = UIFont.systemFont(ofSize: 20)
        return label
    }()
    lazy var secondText:UILabel = {
        let label = UILabel(frame: CGRect(x: 30, y: 33, width: 200, height: 20))
        label.font = UIFont.systemFont(ofSize: 15)
        return label
    }()
    override func layoutSubviews() {
        super.layoutSubviews()
        addSubview(mainText)
        addSubview(secondText)
    }
}
