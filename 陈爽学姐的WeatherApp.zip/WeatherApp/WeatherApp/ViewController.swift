import UIKit
import CoreLocation
import SwiftyJSON
import Alamofire
import NVActivityIndicatorView
import Hero

var ScreenFrame = UIScreen.main.bounds
let ScreenWidth = ScreenFrame.width
let ScreenHeight = ScreenFrame.height

var cityAll :[String] = []                  //存放所有的city名
var cityData : [cityInfo] = []              //存放所有city的信息
var cityViewData:[CityView] = []            //存放配置好的view

var cities:[City] = []                      //搜索框中的数据
var filteredcities = [City]()               //过滤之后的数据
var NowJSON  = JSON()                       //用于数据的暂存

struct City:Decodable{
    var NAMECN = ""
    var PROVCN = ""
}//构建cell数据类型

class ViewController:UIViewController{
    
    //进行定位
    private let locationManager = CLLocationManager()//用于获取用户位置的信息
    private let geocoder = CLGeocoder()//用于编码
    
    let reuseIdenCity = "reuseCellCity"
    var selectedCell : CityColletcionCell?
    var selectedIndex : Int?
    
    let searchController = UISearchController(searchResultsController: nil)
    
    // MARK: - 懒加载属性
    lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.itemSize = CGSize(width: ScreenWidth-40, height: 140)
        let collectionView = UICollectionView(frame: CGRect(x: 20, y: 160, width: ScreenWidth-40, height: ScreenHeight*0.80), collectionViewLayout: layout)
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.backgroundColor = .white
        collectionView.register(CityColletcionCell.classForCoder(), forCellWithReuseIdentifier: reuseIdenCity)
        collectionView.addGestureRecognizer(UILongPressGestureRecognizer(target: self, action: #selector(longPress(sender:))))//设置长按事件
        return collectionView
    }()
    
    @objc func longPress(sender: UILongPressGestureRecognizer) {
        var fromPoint: CGPoint, movementPoint: CGPoint
        switch sender.state {
        case .began:
            fromPoint = sender.location(in: sender.view)
            if let indexPath = collectionView.indexPathForItem(at: fromPoint) {
                collectionView.beginInteractiveMovementForItem(at: indexPath)
            }
        case .changed://在改变时 保持原有的缩小状态
            movementPoint = sender.location(in: sender.view)
            if (sender.view?.point(inside: movementPoint, with: nil))! {
                collectionView.updateInteractiveMovementTargetPosition(movementPoint)
            }
        case .ended:
            collectionView.endInteractiveMovement()
        case .cancelled , .failed:
            collectionView.cancelInteractiveTransition()
        default: break
        }
    }
    
    let reuseIdenData =  "reuseCellData"
    lazy var tableViewData:UITableView = {
        let tableView = UITableView(frame: ScreenFrame)
        tableView.dataSource = self
        tableView.delegate = self
        tableView.backgroundColor = .white
        tableView.register(SearchDataTableCell.self,forCellReuseIdentifier: reuseIdenData)
        tableView.isHidden = true//首先是不显示的
        return tableView
    }()
    // MARK: - 配置
    override func viewDidLoad() {
        super.viewDidLoad()
        configSearchController()
        setupNavigationBarAppearance()
        configNav()
        setupView()
        startView()
    }
    private func configSearchController(){
        searchController.searchResultsUpdater = self
        searchController.hidesNavigationBarDuringPresentation = true//隐藏导航栏
        searchController.obscuresBackgroundDuringPresentation = false
        definesPresentationContext = true//希望搜索框显示在导航栏上并且能够正确工作
        searchController.searchBar.delegate = self
        if let textField = searchController.searchBar.value(forKey: "searchField") as? UITextField {
            textField.leftView?.tintColor = .systemBlue
            let attributes: [NSAttributedString.Key: Any] = [
                .foregroundColor: UIColor.systemBlue
            ]
            textField.attributedPlaceholder = NSAttributedString(
                string: "请输入你想搜索的城市",
                attributes: attributes
            )
        }
    }
    private func setupNavigationBarAppearance() {
        let appearance = UINavigationBarAppearance()
        // 关闭自动样式适配
        appearance.configureWithOpaqueBackground()
        // 固定背景色（示例为白色）
        appearance.backgroundColor = UIColor.white
        // 固定标题颜色（示例为黑色）
        appearance.titleTextAttributes = [
            .foregroundColor: UIColor.black,
            .font:UIFont(name: "Avenir-Book", size: 20)!
        ]
        // 应用于所有状态
        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        navigationController?.navigationBar.tintColor = .black
    }
    private func configNav(){
        self.view.backgroundColor = .white
        self.title = "城市管理"
        navigationController?.hero.isEnabled = true
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false//滑动时不隐藏，是关键语句，设置为true则不会显示
    }
    private func setupView(){
        self.view.addSubview(tableViewData)
        self.view.addSubview(collectionView)
    }
    private func startView(){
        getCityInfo()
//        getJSONData("湘潭")
//        getLocation()//获取位置 进行网络请求 得到json数据 理应在定位协议方法中实现（有城市）
    }
    func getCityInfo(){
        //获取文件路径
        guard let filePath = Bundle.main.path(forResource: "city", ofType: "json")else{
            print("city文件未找到")
            return
        }
        do{
            let fileData = try Data(contentsOf: URL(fileURLWithPath: filePath))//读取文件数据
            cities = try JSONDecoder().decode([City].self, from: fileData)//存储数据
        }catch{
            print("文件读取有误 或 JSON 解析错误:",error)
        }
    }
    func getLocation(){
        locationManager.delegate = self//在此视图控制器中 获取地理位置 方法
        locationManager.desiredAccuracy = kCLLocationAccuracyBest//精度设置
        locationManager.requestWhenInUseAuthorization()// 请求用户授权
        //并且需要在info.plist中添加请求选项
        locationManager.startUpdatingLocation()// 开始获取位置
    }
    // MARK: - 初始化主界面的集合对象 以及得到三个json数据
    func getJSONData(_ city:String){
        
        let apiKey = "4B097C1688cA4A4Db31F534B0EFd9C3e"
        let nowURL = "https://route.showapi.com/9-2?appKey=\(apiKey)"
        let futureURL = "https://route.showapi.com/9-9?appKey=\(apiKey)"
        let todayURL = "https://route.showapi.com/9-8?appKey=\(apiKey)"
        let para : [String:String] = [
            "area" : city
        ]
        
        let urls = [nowURL,futureURL,todayURL]
        let parameters: [Parameters?] = [para,para,para]
        
        var Iden : String = ""
        
        NetWorkManager.shared.fetchMultipleData(urls: urls, parameters: parameters) { result in
            switch result {
            case .success(let dataArray):
                // 处理数据，假设数据是可解析的
                let nowdata = dataArray[0]
                let futuredata = dataArray[1]
                let todaydata = dataArray[2]
                
                NowJSON = JSON(nowdata)
                let minTemp = NowJSON["showapi_res_body"]["f1"]["night_air_temperature"].stringValue//最低
                let maxTemp = NowJSON["showapi_res_body"]["f1"]["day_air_temperature"].stringValue//最高
                let weather = NowJSON["showapi_res_body"]["now"]["weather"].stringValue//天气
                let temperature = NowJSON["showapi_res_body"]["now"]["temperature"].stringValue//温度
                //设置背景需要的参数
                let air = NowJSON["showapi_res_body"]["now"]["aqiDetail"]["quality"].stringValue//空气质量
                let weather_code = NowJSON["showapi_res_body"]["now"]["weather_code"].stringValue//天气图标
                let currentTime = NowJSON["showapi_res_body"]["now"]["temperature_time"].stringValue//得现在的时间
                let sun = NowJSON["showapi_res_body"]["f1"]["sun_begin_end"].stringValue//日出日落时间
                let times = sun.components(separatedBy: "|")
                //设置背景
                if air == "重度污染"||air=="严重污染"||air == "很差"||air == "中度污染"
                {
                    Iden = "badAirDay"//空气质量不好
                }
                if weather_code == "00" || weather_code == "01" || weather_code == "03"{//晴
                    if currentTime > times[1]{//晚上
                        Iden = "sunnyEvening"
                    }else{//早上
                        Iden = "sunnyDay"
                    }
                }else {//下雨
                    if currentTime > times[1]{//晚上
                        Iden = "rainyEvening"
                    }else{//早上
                        Iden = "rainyDay"
                    }
                }
                if currentTime == times[1] || currentTime == times[0]{
                    Iden = "sunRiseSet"
                }
                
                let info = cityInfo(name: city,tem:temperature ,temRange: "\(minTemp)° ~ \(maxTemp)°",weather: weather,backIden: Iden)
                cityAll.append(city)
                cityData.append(info)
                self.collectionView.reloadData()
                
                let viewControllerB = CityView(now: nowdata, future: futuredata,today:todaydata,backID: Iden)
                cityViewData.append(viewControllerB)
                
            case .failure(let error):
                print("Error fetching data: \(error)")
            }
        }
    }

}
// MARK: - 搜索TableView代理方法
extension ViewController:UITableViewDelegate, UITableViewDataSource{//初始化搜索表格
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isFiltering() {
            return filteredcities.count
        }
        return cities.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdenData, for: indexPath) as! SearchDataTableCell
        if isFiltering() {
            cell.mainText.text = filteredcities[indexPath.row].NAMECN
            cell.secondText.text = filteredcities[indexPath.row].PROVCN
        } else {
            cell.mainText.text = cities[indexPath.row].NAMECN
            cell.secondText.text = cities[indexPath.row].PROVCN
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var flag = 0
        let selectedCell = tableView.cellForRow(at: indexPath) as? SearchDataTableCell
        let selectedData = selectedCell?.mainText.text//得到市名
        for i in 0..<cityAll.count{
            if(cityAll[i] == selectedData!){
                flag = 1
                showCityRepeat()
            }else{
                continue
            }
        }
        if flag == 0 {
            getJSONData(selectedData!)//获取数据 得到视图
        }
        searchController.isActive = false//取消搜索状态
        navigationController?.navigationBar.isHidden = false
        searchController.searchBar.resignFirstResponder()//点击单元格后隐藏键盘
        tableView.deselectRow(at: indexPath, animated: true)//取消选择状态
    }
    
    func showCityRepeat(){
        let alert = UIAlertController(title: "重复添加城市‼️", message: "You already have added this city", preferredStyle: .alert)
        let ok = UIAlertAction(title: "Get it", style: .default)
        alert.addAction(ok)
        self.present(alert,animated: true,completion: nil)
    }
}
// MARK: - TableView过滤显示
extension ViewController:UISearchResultsUpdating,UISearchBarDelegate{//更新数据以及隐藏的变换
    func updateSearchResults(for searchController: UISearchController) {
        filterContentForSearchText(searchController.searchBar.text!)//进行过滤
    }
    
    func searchBarIsEmpty() -> Bool {
      return searchController.searchBar.text?.isEmpty ?? true
    }//检查文本是否为空
      
    func filterContentForSearchText(_ searchText: String, scope: String = "All") {
      filteredcities =  cities.filter({( city : City) -> Bool in
          return city.NAMECN.lowercased().contains(searchText.lowercased())
      })//检查数组中是否是我们需要的 是否包含输入的字
      tableViewData.reloadData()
    }
    
    func isFiltering() -> Bool {
      return searchController.isActive && !searchBarIsEmpty()
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        tableViewData.isHidden = false // 显示 tableView
        collectionView.isHidden = true
    }

    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        tableViewData.isHidden = true // 隐藏 tableView
        collectionView.isHidden = false
    }
}
// MARK: - CollectionView代理方法
extension ViewController:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{//初始化集合类型
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return cityAll.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdenCity, for: indexPath) as! CityColletcionCell
        cell.layer.cornerRadius = 25
        cell.cityName.text = cityData[indexPath.row].name
        cell.cityTem.text = cityData[indexPath.row].tem
        cell.cityTemRange.text = cityData[indexPath.row].temRange
        cell.cityWeather.text = cityData[indexPath.row].weather
        HandleData.shared.setWeatherGradientBackground(for: cell, weatherCondition: cityData[indexPath.row].backIden)
        cell.hero.isEnabled = true
        cell.hero.id = "shareId"
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    //选择了cell单元格
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedIndex = indexPath.row
        selectedCell = collectionView.cellForItem(at: indexPath) as? CityColletcionCell//获取选中的单元格
        let detailVC = cityViewData[indexPath.row]//由索引获取具体页面
        
        detailVC.hero.isEnabled = true
        navigationController?.pushViewController(detailVC, animated: true)
    }

    //单元格可以进行移动
    func collectionView(_ collectionView: UICollectionView, canMoveItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func collectionView(_ collectionView: UICollectionView, moveItemAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let fromRow = sourceIndexPath.item
        let toRow = destinationIndexPath.item
        let city = cityData[fromRow]
        let cityView = cityViewData[fromRow]
        
        cityData.remove(at: fromRow)
        cityViewData.remove(at: fromRow)
        cityData.insert(city, at: toRow)
        cityViewData.insert(cityView, at: toRow)
    }
}


// MARK: - 获取位置 得到城市名
extension ViewController: CLLocationManagerDelegate{
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
           guard let location = locations.last else { return }//确保 locations 数组中有最新的位置信息 如果数组为空 则last为nil
           locationManager.stopUpdatingLocation()// 停止位置更新以节省电池
        
           geocoder.reverseGeocodeLocation(location) {
               placemarks, error in
               guard let placemark = placemarks?.first else { return }
               DispatchQueue.main.async {
                   let rawCity = placemark.locality
                   let finalCity = HandleData.shared.formatCityName(rawCity!)
                   print(finalCity)
                   self.getJSONData(finalCity)
                   self.collectionView.reloadData() //主线程更新ui,仍更新不及时
                }
           }
       }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
            print("Failed to get user location: \(error.localizedDescription)")
    }
}
